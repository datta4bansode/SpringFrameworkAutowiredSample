import com.test.service.ISpakerService;
import com.test.service.SpakerService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
    public static void main(String args[])
    {
        ApplicationContext appContext=new AnnotationConfigApplicationContext(AppConfig.class);

        ISpakerService service=appContext.getBean("speakerService",SpakerService.class);

        System.out.println(service.findAll().get(0).getFirstName());
    }
}
