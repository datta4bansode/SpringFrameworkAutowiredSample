import com.test.repository.ISpakerRepository;
import com.test.repository.SpakerRepository;
import com.test.service.ISpakerService;
import com.test.service.SpakerService;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {

    @Bean(name = "speakerService")
    @Scope(value = BeanDefinition.SCOPE_SINGLETON)
    public ISpakerService getSpeakerService() {
        //SpakerService service = new SpakerService(getSpeakerRepository()); constructer injection
        ISpakerService service = new SpakerService();//Autowired
        //service.setRepository(getSpeakerRepository());
        return service;
    }

    @Bean(name = "speakerRepository")
    public ISpakerRepository getSpeakerRepository() {
        return new SpakerRepository();
    }
}
