package com.test.service;

import com.test.model.Speaker;
import com.test.repository.ISpakerRepository;
import com.test.repository.SpakerRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class SpakerService implements ISpakerService {

    private ISpakerRepository spakerRepository;

    public SpakerService() {
        System.out.println("SpakerService not argument constructar");
    }

    public SpakerService(ISpakerRepository spakerService) {
        System.out.println("SpakerService repositroy constructar");
        this.spakerRepository = spakerService;
    }

    @Override
    public List<Speaker> findAll() {
        return spakerRepository.findAll();
    }

    @Autowired
    public void setRepository(ISpakerRepository spakerRepository) {
        System.out.println("SpakerService seter repositroy");
        this.spakerRepository = spakerRepository;
    }
}
