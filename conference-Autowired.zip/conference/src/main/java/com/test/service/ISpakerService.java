package com.test.service;

import com.test.model.Speaker;

import java.util.List;

public interface ISpakerService {
    List<Speaker> findAll();
}
