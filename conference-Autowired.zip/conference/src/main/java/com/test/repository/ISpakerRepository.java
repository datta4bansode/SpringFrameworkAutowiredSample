package com.test.repository;

import com.test.model.Speaker;

import java.util.List;

public interface ISpakerRepository {
    List<Speaker> findAll();
}
