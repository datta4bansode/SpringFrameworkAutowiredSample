package com.test.repository;

import com.test.model.Speaker;

import java.util.ArrayList;
import java.util.List;

public class SpakerRepository implements ISpakerRepository {
    @Override
    public List<Speaker> findAll() {
        List<Speaker> speakers = new ArrayList<Speaker>();

        Speaker speaker=new Speaker();
        speaker.setFirstName("Datta");
        speaker.setLastName("Bansode");

        speakers.add(speaker);
        return speakers;
    }

}
